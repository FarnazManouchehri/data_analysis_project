"""All Phase 2 figures. Each function takes already-computed objects and writes one PNG to artifacts/phase2."""
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.collections import PolyCollection
from matplotlib.patches import FancyBboxPatch, Patch

from .settings import AMBER, FIGS2, PLUM, RED, SLATE, TEAL, save_fig

DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
CLUSTER_COLORS = [TEAL, PLUM, AMBER, RED, SLATE, "#0284c7", "#65a30d", "#db2777", "#78716c", "#ca8a04"]


def _save(fig, name):
    save_fig(fig, name, where=FIGS2)


def _week_axis(ax):
    for d in range(1, 7):
        ax.axvline(24 * d, color="#cbd5e1", lw=0.8, zorder=0)
    ax.set_xticks([12 + 24 * d for d in range(7)], DOW)
    ax.set_xlim(0, 168)
    ax.tick_params(axis="x", length=0)


def fig_pipeline(log: pd.DataFrame, n_panel: int, n_feat_rows: int, n_feats: int) -> None:
    fig, ax = plt.subplots(figsize=(9.8, 2.9))
    ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(0, 3)
    removed = log.set_index("step")["removed"]
    boxes = [
        (0.05, f"raw files\n{log['rows_in'].iloc[0]/1e6:.2f}M trips", SLATE),
        (1.45, f"1-2 window,\nduplicates\n-{removed.iloc[0] + removed.iloc[1]:,}", RED),
        (2.85, f"3 refund /\nvoid rows\n-{removed.iloc[2]:,}", RED),
        (4.25, f"4-5 impossible\ntime / motion\n-{removed.iloc[3] + removed.iloc[4]:,}", RED),
        (5.65, f"6 recode,\ntypes, flags\n{log['rows_out'].iloc[-1]/1e6:.2f}M trips", AMBER),
        (7.05, f"zone x hour\npanel\n{n_panel:,} cells", PLUM),
        (8.45, f"feature table\n{n_feat_rows:,} rows\n{n_feats} feature columns", TEAL),
    ]
    for x, text, c in boxes:
        ax.add_patch(FancyBboxPatch((x, 0.8), 1.3, 1.5, boxstyle="round,pad=0.03,rounding_size=0.1", fc=c, ec="none", alpha=0.92))
        ax.text(x + 0.65, 1.55, text, ha="center", va="center", color="white", fontsize=7.4, fontweight="bold")
    for x in (1.35, 2.75, 4.15, 5.55, 6.95, 8.35):
        ax.annotate("", xy=(x + 0.1, 1.55), xytext=(x - 0.03, 1.55), arrowprops=dict(arrowstyle="-|>", color="#334155", lw=1.3))
    ax.text(5, 0.35, "re-run end to end from the raw files: python -m taxidemand.phase2  (rows removed are charged to the first step that removes them)",
            ha="center", fontsize=7.6, color=SLATE)
    _save(fig, "p2_01_pipeline.png")


def fig_encoding(enc: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.4), gridspec_kw={"width_ratios": [1, 2.1]}, layout="constrained")
    ax = axes[0]
    h = np.arange(24)
    ang = 2 * np.pi * h / 24
    ax.plot(np.sin(ang), np.cos(ang), color="#cbd5e1", lw=1, zorder=0)
    sc = ax.scatter(np.sin(ang), np.cos(ang), c=h, cmap="twilight", s=36, zorder=2)
    for hh in (0, 6, 12, 18, 23):
        ax.annotate(f"{hh:02d}h", (np.sin(ang[hh]), np.cos(ang[hh])), xytext=(1.22 * np.sin(ang[hh]), 1.22 * np.cos(ang[hh])),
                    ha="center", va="center", fontsize=7.5)
    ax.set_aspect("equal"); ax.set_xlim(-1.45, 1.45); ax.set_ylim(-1.45, 1.45)
    ax.set_xlabel("hour_sin"); ax.set_ylabel("hour_cos")
    ax.set_title("a. sin/cos puts 23h next to 00h")
    ax = axes[1]
    order = ["none", "integer", "sin/cos", "one-hot"]
    x = np.arange(len(order))
    r1 = enc[(enc["model"] == "ridge") & (enc["setting"] == "calendar only")].set_index("encoding").loc[order, "WAPE_pct"]
    r2 = enc[(enc["model"] == "ridge") & (enc["setting"] == "with lags")].set_index("encoding").loc[order, "WAPE_pct"]
    g = enc[enc["model"] == "gradient boosting"].set_index("encoding")["WAPE_pct"]
    ax.bar(x - 0.27, r1, 0.26, color=SLATE, label="ridge, zone level + time only")
    ax.bar(x, r2, 0.26, color=TEAL, label="ridge, + weekly / daily lags")
    ax.bar([1 + 0.27, 2 + 0.27], [g["integer"], g["sin/cos"]], 0.26, color=AMBER, label="gradient boosting, + lags")
    for xs, vals in ((x - 0.27, r1), (x, r2), ([1.27, 2.27], [g["integer"], g["sin/cos"]])):
        for xi, v in zip(xs, vals):
            ax.text(xi, v + 0.8, f"{v:.1f}", ha="center", fontsize=7)
    ax.set_xticks(x, ["no hour/day", "integer", "sin / cos", "one-hot"])
    ax.set_ylabel("WAPE on May (%)")
    ax.set_title("b. Encoding of hour and weekday: same model, validation month")
    ax.legend(loc="upper right", fontsize=7.5)
    ax.set_ylim(0, max(r1) * 1.15)
    _save(fig, "p2_02_encoding.png")


def fig_spearman(sp: pd.DataFrame) -> None:
    s = sp.set_index("feature").sort_values("spearman_all")
    fig, ax = plt.subplots(figsize=(8.6, 6.0))
    y = np.arange(len(s))
    ax.barh(y + 0.2, s["spearman_all"], 0.38, color=TEAL, label="across all zone-hours")
    ax.barh(y - 0.2, s["spearman_within_zone"].fillna(0), 0.38, color=AMBER,
            label="within zone (zone mean removed);\nnone for zone-level features, constant within a zone")
    ax.set_yticks(y, s.index, fontsize=7.6)
    ax.axvline(0, color=SLATE, lw=0.8)
    ax.set_xlabel("Spearman correlation with hourly pickups (train, Jan 29 - Apr 30)")
    ax.set_title("Which features carry signal, and of which kind")
    ax.legend(loc="lower right", fontsize=7.5)
    _save(fig, "p2_03_feature_spearman.png")


def fig_pca(P: dict) -> None:
    pca = P["pca"]
    full = np.cumsum(P["var_explained"])
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.2), gridspec_kw={"width_ratios": [1, 2.2]}, layout="constrained")
    ax = axes[0]
    k = np.arange(1, len(full) + 1)
    ax.bar(k, P["var_explained"], color=TEAL, alpha=0.8)
    ax.plot(k, full, color=AMBER, marker="o", ms=3)
    ax.axhline(0.9, color=SLATE, ls="--", lw=0.8)
    ax.text(len(full), 0.86, "90%", ha="right", fontsize=7.5, color=SLATE)
    ax.set_xlabel("principal component"); ax.set_ylabel("share of variance")
    ax.set_xticks(k[::2])
    ax.set_title(f"a. {P['pcs_kept']} PCs keep 90% of the variance")
    ax = axes[1]
    for i, c in enumerate((TEAL, PLUM)):
        ax.plot(pca.components_[i], color=c, lw=1.4, label=f"PC{i+1} ({100*P['var_explained'][i]:.0f}%)")
    ax.axhline(0, color=SLATE, lw=0.6)
    _week_axis(ax)
    ax.set_ylabel("loading")
    ax.set_title("b. Loadings over the 168 hours of the week")
    ax.legend(fontsize=7.5, loc="lower left", ncol=2)
    _save(fig, "p2_04_pca.png")


def fig_k_selection(ktab: pd.DataFrame, min_ari: float) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.2), layout="constrained")
    k = ktab["k"]
    ch = int(ktab.loc[ktab["chosen"], "k"].iloc[0])
    ax = axes[0]
    ax.plot(k, ktab["silhouette_kmeans"], marker="o", color=TEAL, label="k-means")
    ax.plot(k, ktab["silhouette_ward"], marker="s", color=PLUM, ls="--", label="Ward (hierarchical)")
    ax.set_xlabel("k"); ax.set_ylabel("silhouette")
    ax.set_title("a. Separation")
    ax.legend(fontsize=7.5)
    ax = axes[1]
    ax.plot(k, ktab["seed_ari_median"], marker="o", color=TEAL, label="seed (single-start k-means)")
    ax.plot(k, ktab["boot_ari_median"], marker="s", color=AMBER, label="bootstrap of train weeks")
    ax.plot(k, ktab["scale_ari_share_col_z"], marker="^", color=SLATE, ls=":", label="scaling: standardised hours")
    ax.plot(k, ktab["scale_ari_row_z"], marker="v", color=RED, ls=":", label="scaling: per-zone z-score")
    ax.axhline(min_ari, color=SLATE, ls="--", lw=0.8)
    ax.set_xlabel("k"); ax.set_ylabel("ARI with the reference partition (median)")
    ax.set_title("b. Stability")
    ax.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2)
    ax.set_ylim(-0.15, 1.05)
    for a in axes:
        a.axvspan(ch - 0.3, ch + 0.3, color=AMBER, alpha=0.15, zorder=0)
        a.set_xticks(k)
    _save(fig, "p2_05_k_selection.png")


def fig_cluster_profiles(P: dict, labels: np.ndarray, names: dict) -> None:
    X = P["mean_week"] / P["mean_week"].sum(1, keepdims=True) * 100
    fig, ax = plt.subplots(figsize=(9.8, 3.4))
    for c in sorted(set(labels)):
        Xc = X[labels == c]
        for row in Xc:
            ax.plot(row, color=CLUSTER_COLORS[c - 1], lw=0.35, alpha=0.18)
        ax.plot(Xc.mean(0), color=CLUSTER_COLORS[c - 1], lw=2, label=f"{c}. {names[c]} ({len(Xc)} zones)")
    _week_axis(ax)
    ax.set_ylabel("% of the zone's weekly pickups")
    ax.set_title("Weekly profile of each zone (thin) and cluster mean (thick); train months")
    ax.legend(fontsize=7.5, loc="upper left")
    ax.set_ylim(0, 1.08 * max(X[labels == c].mean(0).max() for c in set(labels)))
    _save(fig, "p2_06_cluster_profiles.png")


def fig_cluster_map(rings: dict, labels: pd.Series, names: dict) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 7.0))
    polys, colors = [], []
    for zid, parts in rings.items():
        col = CLUSTER_COLORS[labels[zid] - 1] if zid in labels.index else "#e2e8f0"
        for r in parts:
            polys.append(r / 5280.0)
            colors.append(col)
    ax.add_collection(PolyCollection(polys, facecolors=colors, edgecolors="white", linewidths=0.3))
    ax.autoscale_view(); ax.set_aspect("equal"); ax.set_axis_off()
    handles = [Patch(color=CLUSTER_COLORS[c - 1], label=f"{c}. {names[c]}") for c in sorted(names)]
    handles.append(Patch(color="#e2e8f0", label="not active (< 10 pickups/day)"))
    ax.legend(handles=handles, loc="upper left", fontsize=7.5)
    ax.set_title("Zone clusters on the map (polygons: TLC taxi_zones shapefile)")
    _save(fig, "p2_07_cluster_map.png")


def fig_pca_scatter(P: dict, labels: np.ndarray, act: pd.Index, zone_names: pd.Series, names: dict) -> None:
    Z = P["Z"]
    fig, ax = plt.subplots(figsize=(8.0, 4.6))
    for c in sorted(set(labels)):
        m = labels == c
        ax.scatter(Z[m, 0], Z[m, 1], s=22, color=CLUSTER_COLORS[c - 1], label=f"{c}. {names[c]}", alpha=0.85, edgecolor="white", lw=0.4)
    for zid in (161, 132, 138, 79, 249, 76, 236, 186, 43, 61):
        if zid in act:
            i = act.get_loc(zid)
            ax.annotate(zone_names[zid], (Z[i, 0], Z[i, 1]), xytext=(4, 3), textcoords="offset points", fontsize=6.6, color="#1e293b")
    ax.set_xlabel(f"PC1 ({100*P['var_explained'][0]:.0f}% of variance)")
    ax.set_ylabel(f"PC2 ({100*P['var_explained'][1]:.0f}%)")
    ax.set_title("Active zones in the plane of the first two principal components")
    ax.legend(fontsize=7.5, loc="best")
    _save(fig, "p2_08_pca_scatter.png")


def fig_day_clusters(days: pd.DataFrame, D: pd.DataFrame, names: dict) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.3), gridspec_kw={"width_ratios": [1.4, 1]}, layout="constrained")
    ax = axes[0]
    lab = days.set_index("date")["cluster"]
    for c in sorted(lab.unique()):
        rows = D.loc[lab[lab == c].index]
        for _, r in rows.iterrows():
            ax.plot(100 * r.values, color=CLUSTER_COLORS[c - 1], lw=0.4, alpha=0.25)
        ax.plot(100 * rows.mean().values, color=CLUSTER_COLORS[c - 1], lw=2.2, label=f"{c}. {names[c]} ({len(rows)} days)")
    for d, nm in (("2024-01-15", "MLK"), ("2024-02-19", "Presidents'")):
        ax.plot(100 * D.loc[pd.Timestamp(d)].values, color="#1e293b", lw=1, ls="--")
    ax.plot([], [], color="#1e293b", lw=1, ls="--", label="MLK Day, Presidents' Day")
    ax.set_xticks(range(0, 24, 3)); ax.set_xlabel("hour"); ax.set_ylabel("% of the day's pickups")
    ax.set_title("a. City-wide daily curve, Jan-May")
    ax.legend(fontsize=7, loc="upper left")
    ax = axes[1]
    start = days["date"].min()
    wk = ((days["date"] - start).dt.days // 7).to_numpy()
    for (_, r), w in zip(days.iterrows(), wk):
        ax.add_patch(plt.Rectangle((w, 6 - r["dow"]), 0.92, 0.92, fc=CLUSTER_COLORS[r["cluster"] - 1], ec="white", lw=0.6))
        if r["kind"] == "holiday":
            ax.plot(w + 0.46, 6 - r["dow"] + 0.46, marker="*", color="white", ms=7, mec="#1e293b", mew=0.5)
    ax.set_xlim(0, wk.max() + 1); ax.set_ylim(0, 7)
    ax.set_yticks(np.arange(7) + 0.46, DOW[::-1]); ax.set_xticks([])
    ax.grid(False)
    ax.set_title("b. Calendar (one column per week, * = holiday)")
    _save(fig, "p2_09_day_clusters.png")


def fig_anomalies(A: dict, panel: pd.DataFrame, table: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(9.8, 5.4), layout="constrained")
    ax = axes[0]
    dc = A["daily_counts"].reindex(columns=["above", "below"], fill_value=0)
    ax.bar(dc.index, dc["above"], color=TEAL, width=0.9, label="above profile")
    ax.bar(dc.index, -dc["below"], color=RED, width=0.9, label="below profile")
    notes = (("2024-02-11", 40, "Super Bowl night", "center"), ("2024-02-13", -50, "snow", "left"),
             ("2024-02-19", -78, "Presidents' Day", "center"), ("2024-03-10", 22, "clock change", "center"),
             ("2024-03-28", -16, "Midtown, 28 Mar", "center"), ("2024-05-27", -190, "Memorial Day weekend ", "right"))
    for d, y, txt, ha in notes:
        ax.text(pd.Timestamp(d), y, txt, ha=ha, va="center", fontsize=6.8, color="#1e293b")
    ax.axhline(0, color=SLATE, lw=0.6)
    ax.set_ylim(-205, 70)
    ax.set_ylabel("flagged zone-hours per day")
    ax.set_title("a. Zone-hour anomaly candidates per day, January-May")
    ax.legend(fontsize=7.5, loc="lower left")
    ax = axes[1]
    for zid, col, nm in ((161, TEAL, "Midtown Center"), (163, PLUM, "Midtown North")):
        z = table[(table["zone_id"] == zid) & table["ts"].between("2024-03-25", "2024-03-31 23:00")]
        prof = table[(table["zone_id"] == zid) & (table["split"] == "train")].groupby(["dow", "hour"])["pickups"].mean()
        exp = prof.reindex(list(zip(z["dow"], z["hour"]))).to_numpy()
        ax.plot(z["ts"], z["pickups"], color=col, lw=1.2, label=f"{nm}: actual")
        ax.plot(z["ts"], exp, color=col, lw=0.9, ls="--", alpha=0.8, label=f"{nm}: train profile")
    ax.axvline(pd.Timestamp("2024-03-28 17:00"), color=RED, lw=0.8)
    ax.set_ylabel("pickups per hour")
    ax.set_title("b. Thursday 28 March 17:00: both Midtown zones drop to 34-42% of their usual level in the same hour")
    ax.legend(fontsize=7, ncol=2, loc="upper left")
    _save(fig, "p2_10_anomalies.png")


def fig_cluster_features(static: pd.DataFrame, names: dict) -> None:
    cols = [("night_share", "night share (22-06h)", 100), ("weekend_ratio", "weekend / weekday daily pickups", 1),
            ("median_trip_mi", "median trip distance (mi)", 1), ("dist_midtown_mi", "distance to Midtown (mi)", 1)]
    fig, axes = plt.subplots(1, 4, figsize=(9.8, 2.9), layout="constrained")
    cl = sorted(static["cluster"].unique())
    for ax, (c, title, mult) in zip(axes, cols):
        data = [static.loc[static["cluster"] == k, c].dropna() * mult for k in cl]
        bp = ax.boxplot(data, patch_artist=True, widths=0.6, medianprops=dict(color="white", lw=1.5), flierprops=dict(ms=3))
        for patch, k in zip(bp["boxes"], cl):
            patch.set_facecolor(CLUSTER_COLORS[k - 1]); patch.set_edgecolor("none")
        ax.set_xticks(range(1, len(cl) + 1), [str(k) for k in cl])
        ax.set_title(title, fontsize=8.5)
    axes[0].set_xlabel("cluster")
    fig.suptitle("  ".join(f"{k} = {names[k]}" for k in cl), fontsize=7.8, color=SLATE)
    _save(fig, "p2_11_cluster_features.png")
