"""Phase 2 cleaning pipeline: raw trips -> clean, typed trips -> zone-hour panel.

The steps run in a fixed order and each one is a plain function, so the whole chain is re-run from
the raw files every time (no hand edits). `run_steps` records rows in and out of every step in
`tables/cleaning_log.csv`; a removed row is charged to the first step that removes it.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .checks import UNKNOWN_ZONES, add_flags
from .settings import STAGED, TABLES2, params

RATECODES = {1: "standard", 2: "jfk_flat", 3: "newark", 4: "nassau_westchester", 5: "negotiated", 6: "group"}
PAYMENTS = {0: "flex_fare", 1: "card", 2: "cash", 3: "no_charge", 4: "dispute"}


def drop_flagged(t: pd.DataFrame, flags: list[str]) -> pd.DataFrame:
    return t[~t[flags].any(axis=1)]


def recode(t: pd.DataFrame) -> pd.DataFrame:
    """Types and codes: impossible codes become missing, codes become labelled categories."""
    t = t.copy()
    t["meta_missing"] = t["q_no_meta"]  # explicit indicator; the block is not missing at random
    t["passengers"] = t["passengers"].mask(t["q_pass_zero"] | t["q_pass_many"])  # 0 and >6 -> unknown
    rc = t["ratecode"].mask(t["q_ratecode_99"]).astype("Int8")
    t["ratecode"] = pd.Categorical(rc.map(RATECODES).fillna("unknown"),
                                   categories=[*RATECODES.values(), "unknown"])
    t["payment"] = pd.Categorical(t["payment"].map(PAYMENTS).fillna("other"),
                                  categories=[*PAYMENTS.values(), "other"])
    t["short_trip"] = t["q_dur_short"]
    t["zero_distance"] = t["q_dist_zero"]
    keep = ["vendor", "pickup", "pu", "do", "passengers", "ratecode", "payment", "trip_distance",
            "duration_min", "speed_mph", "fare_amount", "tip_amount", "total_amount", "hour", "dow",
            "meta_missing", "short_trip", "zero_distance"]
    return t[keep]


def steps() -> list[tuple[str, str, callable]]:
    """(name, rule, function). Order matters only for which step a removed row is charged to."""
    return [
        ("1 window", "pickup outside the study window", lambda t: drop_flagged(t, ["q_outside_window"])),
        ("2 duplicates", "exact copy of another record", lambda t: drop_flagged(t, ["q_exact_dup"])),
        ("3 reversals", "negative fare or total (refund/void row)", lambda t: drop_flagged(t, ["q_reversal"])),
        ("4 impossible time", "dropoff <= pickup, or meter running > 5 h",
         lambda t: drop_flagged(t, ["q_dur_nonpos", "q_dur_long"])),
        ("5 impossible motion", "distance > 200 mi, speed > 80 mph or fare > $1,000",
         lambda t: drop_flagged(t, ["q_dist_huge", "q_speed", "q_fare_huge"])),
        ("6 recode and type", "codes 0/>6 passengers and ratecode 99 -> missing; labelled categories", recode),
    ]


def run_steps(trips: pd.DataFrame) -> pd.DataFrame:
    t = add_flags(trips)
    log = []
    for name, rule, fn in steps():
        n0 = len(t)
        t = fn(t)
        log.append({"step": name, "rule": rule, "rows_in": n0, "rows_out": len(t), "removed": n0 - len(t)})
    pd.DataFrame(log).to_csv(TABLES2 / "cleaning_log.csv", index=False)
    t = t.reset_index(drop=True)
    t.to_parquet(STAGED / "trips_clean.parquet", index=False, compression="zstd")
    return t


def missing_table(clean: pd.DataFrame) -> pd.DataFrame:
    """One row per variable with missing or structurally absent values, and the decision taken."""
    n = len(clean)
    mm = clean["meta_missing"]
    rows = [
        ("passengers", "numeric", clean["passengers"].isna().mean(),
         f"{100 * mm.mean():.2f}% from the metadata block (payment code 0, concentrated at night and in vendor 6) "
         "plus codes 0 and >6",
         "not imputed. The demand target counts trips and does not need it; zone features use observed rows "
         "only, next to a separate 'share of rows with missing metadata' feature"),
        ("ratecode", "categorical", (clean["ratecode"] == "unknown").mean(),
         "same block, plus code 99 which is not in the data dictionary",
         "own level 'unknown'. Filling with 'standard' would hide that these trips differ (higher median fare)"),
        ("congestion / airport fee", "numeric", mm.mean(),
         "same block; vendor 1 also folds these fees into 'extra'",
         "not used in Phase 2 features; fare modelling is out of scope"),
        ("store_and_fwd_flag", "categorical", mm.mean(), "same block", "column dropped: no analytical use"),
        ("zone-hour with no trips", "count", np.nan, "a real zero: no trip started",
         "kept as 0, never treated as missing"),
        ("DST gap hour 2024-03-10 02:00", "count", np.nan, "the hour does not exist on the local clock",
         "removed from the panel (NaN); lags that point at it stay NaN"),
        ("lags at the start of the window", "numeric", np.nan, "no history before 2024-01-01",
         "rows inside the 4-week warm-up are dropped from the feature table, not imputed"),
    ]
    out = pd.DataFrame(rows, columns=["variable", "type", "missing_share", "why_missing", "decision"])
    out["missing_share"] = (100 * out["missing_share"]).round(2)
    out.to_csv(TABLES2 / "missing_data.csv", index=False)
    return out


def build_panel(clean: pd.DataFrame) -> pd.DataFrame:
    """Complete zone x hour grid of pickups; zeros are real, the DST gap hour is NaN."""
    p = params()
    w = p["window"]
    t = clean.loc[~clean["pu"].isin(UNKNOWN_ZONES), ["pickup", "pu"]]
    counts = t.groupby([t["pu"].rename("zone_id"), t["pickup"].dt.floor("h").rename("ts")]).size()
    hours = pd.date_range(w["start"], w["end"], freq="h", inclusive="left")
    grid = pd.MultiIndex.from_product([np.arange(1, 264, dtype="int16"), hours], names=["zone_id", "ts"])
    panel = counts.reindex(grid, fill_value=0).astype("float32").rename("pickups").reset_index()
    gap = panel["ts"].isin(pd.to_datetime(p["prep"]["dst_gap_hours"]))
    panel.loc[gap, "pickups"] = np.nan
    panel.to_parquet(STAGED / "zone_hour_panel_v2.parquet", index=False)
    return panel
