"""Run Phase 2 end to end from the raw files: cleaning pipeline, features, PCA and clustering,
anomaly candidates. Tables, figures and headline.json go to artifacts/phase2.

    python -m taxidemand.phase2
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd

from . import demand, features, figures_p2, geo, oddities, patterns, refine
from .ingest import load_trips, load_zones
from .settings import OUT2, dump, params, prepare_dirs, theme


def main() -> None:
    t0 = time.time()
    prm = params()
    seed = prm["seed"]
    np.random.seed(seed)
    prepare_dirs(); theme()
    H: dict = {}
    names = {k: {int(i): v for i, v in d.items()} for k, d in prm["patterns"]["names"].items()}

    # 1. Cleaning pipeline and missing-data decisions
    clean = refine.run_steps(load_trips())
    log = pd.read_csv(OUT2 / "tables" / "cleaning_log.csv")
    H["cleaning_log"] = log.to_dict("records")
    H["clean_rows"] = len(clean)
    H["missing"] = refine.missing_table(clean).fillna("").to_dict("records")
    panel = refine.build_panel(clean)
    zones = load_zones()
    shapes, rings = geo.load_shapes()
    act = demand.active_zones(panel.fillna(0))
    H["active_zones"] = len(act)
    print(f"cleaned {len(clean):,} rows  [{time.time()-t0:.0f}s]")

    # 2. Zone patterns (train weeks only), so the cluster label can be a feature
    W = patterns.week_tensor(panel, act)
    ktab, P = patterns.choose_k(W, seed)
    lab = pd.Series(patterns.order_clusters(P["labels"], P["mean_week"]), index=act, name="cluster")
    H["k_selection"] = ktab.round(4).to_dict("records")
    H["k"], H["pcs_kept"] = P["k"], P["pcs_kept"]
    H["var_explained_first5"] = [round(v, 4) for v in P["var_explained"][:5]]
    H["var_explained_kept"] = float(np.sum(P["var_explained"]))
    H["scaling_ari"] = P["scaling_ari"]
    H["train_weeks"] = int(W.shape[1])

    # 3. Features
    table, static = features.build_table(clean, panel, zones, act, shapes, lab)
    H["feature_rows"], H["feature_cols"] = table.shape
    H["feature_split_rows"] = table["split"].value_counts().to_dict()
    cat = features.catalog()
    H["catalog_groups"] = cat["group"].value_counts().to_dict()
    sp = features.spearman_table(table)
    H["spearman"] = sp.round(3).to_dict("records")
    enc = features.encoding_experiment(table, seed)
    H["encoding"] = enc.round(3).to_dict("records")
    cp = patterns.describe_clusters(lab, static, zones, P["mean_week"], act)
    H["clusters"] = cp.round(3).to_dict("records")
    days, dsil, D = patterns.day_clusters(panel, seed)
    H["day_silhouette"] = dsil.round(3).to_dict("records")
    H["day_crosstab"] = pd.crosstab(days["cluster"], days["kind"]).to_dict()
    H["holiday_day_clusters"] = days[days["kind"] == "holiday"].astype(str).to_dict("records")
    print(f"features and patterns  [{time.time()-t0:.0f}s]")

    # 4. Anomaly candidates
    trip_c = oddities.trip_candidates(clean, log)
    H["trip_candidates"] = trip_c.round(4).to_dict("records")
    A = oddities.zone_hour_candidates(table, zones)
    H["zone_hour_flags"], H["zone_hour_searched"] = len(A["flags"]), A["searched"]
    H["zone_hour_kinds"] = A["flags"]["kind"].value_counts().to_dict()
    H["zone_hour_direction"] = A["flags"]["direction"].value_counts().to_dict()
    H["citywide_days"] = A["city_days"].reset_index().astype(str).to_dict("records")
    H["top_isolated"] = A["top_isolated"][["ts", "zone", "pickups", "expected", "z"]].round(1).astype(str).to_dict("records")
    H["hours_below_half_of_profile"] = A["feed_gaps"].round(3).reset_index().astype(str).to_dict("records")

    # 5. Figures
    figures_p2.fig_pipeline(log, len(panel), len(table), table.shape[1] - 4)  # minus zone_id, ts, pickups, split
    figures_p2.fig_encoding(enc)
    figures_p2.fig_spearman(sp)
    figures_p2.fig_pca(P)
    figures_p2.fig_k_selection(ktab, prm["patterns"]["min_stability_ari"])
    figures_p2.fig_cluster_profiles(P, lab.to_numpy(), names["zone"])
    figures_p2.fig_cluster_map(rings, lab, names["zone"])
    figures_p2.fig_pca_scatter(P, lab.to_numpy(), act, zones.set_index("zone_id")["zone"], names["zone"])
    figures_p2.fig_day_clusters(days, D, names["day"])
    figures_p2.fig_anomalies(A, panel, table)
    figures_p2.fig_cluster_features(static, names["zone"])

    dump(H, "headline.json", where=OUT2)
    print(f"done in {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
