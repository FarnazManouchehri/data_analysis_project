"""Feature table for the active-zone x hour panel, the feature catalogue, and the cyclic-encoding test.

Timing rule (Phase 1): the forecast for day T is issued at 00:00 of T, so a feature for hour h of T
may only use hours up to 23:00 of T-1. Every lag is therefore >= 24 h, and daily aggregates use
day T-1 or earlier. Anything learned from data (zone statistics, scalers) is fitted on train only.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from . import geo
from .demand import HOLIDAYS, metrics, split_of
from .settings import STAGED, TABLES2, params

LAGS = (24, 48, 168, 336)


def zone_static(clean: pd.DataFrame, panel: pd.DataFrame, zones: pd.DataFrame, act: pd.Index,
                shapes: pd.DataFrame) -> pd.DataFrame:
    """One row per active zone. Trip-based statistics come from the train months only."""
    p = params()
    prep, train_end = p["prep"], pd.Timestamp(p["split"]["train_end"])
    tr = clean[(clean["pickup"] < train_end) & clean["pu"].isin(act)]
    borough = zones.set_index("zone_id")["borough"]
    g = tr.groupby("pu")
    moving = tr[~tr["zero_distance"]]
    s = pd.DataFrame({
        "median_trip_mi": moving.groupby("pu")["trip_distance"].median(),
        "median_duration_min": g["duration_min"].median(),
        "airport_bound_share": g["do"].apply(lambda d: d.isin(prep["airport_zones"]).mean()),
        "manhattan_bound_share": g["do"].apply(lambda d: (d.map(borough) == "Manhattan").mean()),
        "night_share": g["hour"].apply(lambda h: h.isin(prep["night_hours"]).mean()),
        "meta_missing_share": g["meta_missing"].mean(),
        "mean_passengers": g["passengers"].mean(),  # observed rows only (NaN skipped)
        "card_share": g["payment"].apply(lambda x: (x == "card").mean()),
    })
    od = tr.groupby(["pu", "do"]).size()
    share = od / od.groupby(level=0).transform("sum")
    s["dest_entropy_bits"] = -(share * np.log2(share)).groupby(level=0).sum()
    days = tr["pickup"].dt.normalize()
    daily = tr.groupby(["pu", days]).size().unstack(fill_value=0)
    wk = daily.columns.dayofweek >= 5
    s["weekend_ratio"] = daily.loc[:, wk].mean(axis=1) / daily.loc[:, ~wk].mean(axis=1)

    ptr = panel[(split_of(panel["ts"]) == "train") & panel["zone_id"].isin(act)]
    s["zone_level"] = np.log1p(ptr.groupby("zone_id")["pickups"].mean())
    sh = shapes.set_index("zone_id")
    s["area_sqmi"] = sh["area_sqmi"]
    s["dist_midtown_mi"] = geo.distance_miles(shapes, prep["midtown_zone"]).set_axis(shapes["zone_id"])
    s["dist_airport_mi"] = pd.concat([geo.distance_miles(shapes, a).set_axis(shapes["zone_id"])
                                      for a in prep["airport_zones"]], axis=1).min(axis=1)
    s["log_pickups_per_sqmi"] = np.log1p(ptr.groupby("zone_id")["pickups"].sum() / ptr["ts"].nunique() * 24
                                         / sh["area_sqmi"])
    s["borough"] = borough
    s["is_airport"] = s.index.isin(prep["airport_zones"])
    s.index.name = "zone_id"
    return s.loc[act]


def dynamic(panel: pd.DataFrame, act: pd.Index) -> pd.DataFrame:
    """Calendar, cyclic and lag features for every active zone-hour (warm-up rows removed later)."""
    p = params()
    city = panel.groupby("ts")["pickups"].sum(min_count=1)
    d = panel[panel["zone_id"].isin(act)].sort_values(["zone_id", "ts"]).reset_index(drop=True)
    g = d.groupby("zone_id")["pickups"]
    for lag in LAGS:
        d[f"lag_{lag}"] = g.shift(lag)
    d["same_hour_mean_7d"] = pd.concat([g.shift(24 * k) for k in range(1, 8)], axis=1).mean(axis=1)
    d["same_hour_week_mean_4w"] = pd.concat([g.shift(168 * k) for k in range(1, 5)], axis=1).mean(axis=1)
    day = d["ts"].dt.normalize()
    daily = d.groupby(["zone_id", day])["pickups"].mean().rename("prev_day_mean").reset_index()
    daily["ts"] = daily["ts"] + pd.Timedelta(days=1)  # yesterday's mean, known at 00:00 today
    d = d.merge(daily.rename(columns={"ts": "day"}), left_on=["zone_id", day.rename("day")],
                right_on=["zone_id", "day"], how="left").drop(columns="day")
    d["city_lag_24"] = (d["ts"] - pd.Timedelta(hours=24)).map(city)

    d["hour"], d["dow"], d["month"] = d["ts"].dt.hour, d["ts"].dt.dayofweek, d["ts"].dt.month
    d["is_weekend"] = d["dow"] >= 5
    hol = pd.to_datetime(list(HOLIDAYS))
    d["is_holiday"] = d["ts"].dt.normalize().isin(hol)
    d["is_pre_holiday"] = (d["ts"].dt.normalize() + pd.Timedelta(days=1)).isin(hol)
    d["trend_days"] = (d["ts"] - pd.Timestamp(p["window"]["start"])).dt.days
    for col, period in (("hour", 24), ("dow", 7), ("month", 12)):
        d[f"{col}_sin"] = np.sin(2 * np.pi * d[col] / period)
        d[f"{col}_cos"] = np.cos(2 * np.pi * d[col] / period)
    d["split"] = split_of(d["ts"]).values
    warm = d["ts"] < pd.Timestamp(p["window"]["start"]) + pd.Timedelta(hours=p["prep"]["warmup_hours"])
    return d[~warm & d["pickups"].notna()].reset_index(drop=True)


def build_table(clean, panel, zones, act, shapes, clusters: pd.Series) -> tuple[pd.DataFrame, pd.DataFrame]:
    static = zone_static(clean, panel, zones, act, shapes)
    static["cluster"] = clusters.reindex(static.index)
    table = dynamic(panel, act).merge(static, left_on="zone_id", right_index=True, how="left")
    table.to_parquet(STAGED / "features_zone_hour.parquet", index=False)
    static.to_csv(TABLES2 / "zone_features.csv")
    return table, static


# name, group, definition, information it adds
CATALOG = [
    ("hour, dow, month", "calendar", "clock hour, weekday (0 = Mon), month of the target hour",
     "daily and weekly rhythm; month only as a label (6 months cover half a yearly cycle)"),
    ("hour_sin/cos, dow_sin/cos, month_sin/cos", "cyclic", "sin and cos of 2*pi*value/period",
     "puts 23:00 next to 00:00 and Sunday next to Monday for models that read numbers as distances"),
    ("is_weekend, is_holiday, is_pre_holiday", "calendar", "flags from the federal holiday list in demand.HOLIDAYS",
     "holidays behave like weekends; the evening before a holiday behaves like a Friday"),
    ("trend_days", "calendar", "days since 2024-01-01", "the +25% Jan->May rise in demand"),
    ("lag_24, lag_48", "lag", "pickups in the same zone 24 / 48 h earlier", "recent level, including short-lived shocks"),
    ("lag_168, lag_336", "lag", "pickups in the same zone and hour 1 / 2 weeks earlier",
     "weekly seasonality: strongest autocorrelation in Phase 1"),
    ("same_hour_mean_7d", "lag", "mean of lags 24, 48, ..., 168", "same hour, smoothed over the last week"),
    ("same_hour_week_mean_4w", "lag", "mean of lags 168, 336, 504, 672",
     "same hour and weekday, smoothed over 4 weeks (less noisy than lag_168)"),
    ("prev_day_mean", "lag", "mean hourly pickups of the zone on day T-1", "yesterday's overall level in the zone"),
    ("city_lag_24", "lag", "pickups across all 263 zones 24 h earlier", "city-wide shocks (weather, holidays)"),
    ("zone_level", "zone (train)", "log(1 + mean hourly pickups) in train", "how busy the zone is"),
    ("median_trip_mi, median_duration_min", "zone (train)", "median distance / duration of trips leaving the zone",
     "short hops (Midtown) versus long rides (airports, outer boroughs)"),
    ("airport_bound_share, manhattan_bound_share", "zone (train)", "share of departing trips that end at an airport / in Manhattan",
     "what the zone is connected to: hotel and business zones feed airports"),
    ("dest_entropy_bits", "zone (train)", "Shannon entropy of the destination-zone distribution",
     "a hub with many destinations versus a zone with a few fixed links"),
    ("night_share, weekend_ratio", "zone (train)", "share of pickups 22:00-05:59; weekend / weekday daily mean",
     "nightlife and leisure versus office use"),
    ("meta_missing_share, mean_passengers, card_share", "zone (train)",
     "share of rows in the metadata block; mean observed passengers; share paid by card",
     "data-quality and customer mix of the zone"),
    ("area_sqmi, log_pickups_per_sqmi", "spatial", "polygon area; log demand density", "zone size versus intensity"),
    ("dist_midtown_mi, dist_airport_mi", "spatial", "centroid distance to Midtown Center (zone 161) / nearest airport",
     "position relative to the core and to the airports"),
    ("borough, is_airport", "spatial", "borough of the zone; JFK, LaGuardia or Newark", "administrative and airport effects"),
    ("cluster", "pattern", "k-means cluster of the zone's weekly profile (section 6)",
     "the shape of the zone's week in one categorical feature"),
]


def catalog() -> pd.DataFrame:
    out = pd.DataFrame(CATALOG, columns=["feature", "group", "definition", "information_added"])
    out["available_at_issue"] = np.where(out["group"].eq("lag"), "yes, every lag >= 24 h", "yes, known in advance")
    out.loc[out["group"].isin(["zone (train)", "pattern"]), "available_at_issue"] = "yes, fitted on Jan-Apr only"
    out.to_csv(TABLES2 / "feature_catalog.csv", index=False)
    return out


def spearman_table(table: pd.DataFrame) -> pd.DataFrame:
    tr = table[table["split"] == "train"]
    cols = ["lag_24", "lag_48", "lag_168", "lag_336", "same_hour_mean_7d", "same_hour_week_mean_4w",
            "prev_day_mean", "city_lag_24", "zone_level", "log_pickups_per_sqmi", "dist_midtown_mi",
            "dist_airport_mi", "median_trip_mi", "airport_bound_share", "manhattan_bound_share",
            "dest_entropy_bits", "night_share", "weekend_ratio", "meta_missing_share", "card_share",
            "hour", "hour_sin", "hour_cos", "dow", "trend_days"]
    rows = []
    for c in cols:
        ok = tr[c].notna()
        rho = stats.spearmanr(tr.loc[ok, c], tr.loc[ok, "pickups"]).statistic
        # Within-zone rho removes the "busy zones are busy" effect that static features ride on.
        dev = tr.loc[ok, "pickups"] - tr.loc[ok].groupby("zone_id")["pickups"].transform("mean")
        cdev = tr.loc[ok, c] - tr.loc[ok].groupby("zone_id")[c].transform("mean")
        constant = tr.loc[ok].groupby("zone_id")[c].nunique().max() <= 1  # zone feature: no within-zone variation
        within = np.nan if constant else stats.spearmanr(cdev, dev).statistic
        rows.append({"feature": c, "spearman_all": rho, "spearman_within_zone": within})
    out = pd.DataFrame(rows)
    out.to_csv(TABLES2 / "feature_spearman.csv", index=False)
    return out


def encoding_experiment(table: pd.DataFrame, seed: int) -> pd.DataFrame:
    """Same model, different encodings of hour and weekday; scored by WAPE on May (validation)."""
    d = table.dropna(subset=["lag_24", "lag_168", "same_hour_mean_7d"])
    tr, va = d[d["split"] == "train"], d[d["split"] == "valid"]
    lag_cols = ["lag_24", "lag_168", "same_hour_mean_7d", "same_hour_week_mean_4w"]
    enc = {
        "none": ([], []),
        "integer": (["hour", "dow"], []),
        "sin/cos": (["hour_sin", "hour_cos", "dow_sin", "dow_cos"], []),
        "one-hot": ([], ["hour", "dow"]),
    }
    rows = []
    for setting, base in (("calendar only", ["zone_level"]), ("with lags", ["zone_level", *lag_cols])):
        for name, (num, cat) in enc.items():
            X = lambda f: f[base + num + cat].assign(**{c: np.log1p(f[c]) for c in base if c.startswith(("lag", "same"))})  # noqa: E731
            ct = ColumnTransformer([("num", StandardScaler(), base + num)] +
                                   ([("cat", OneHotEncoder(handle_unknown="ignore"), cat)] if cat else []))
            m = make_pipeline(ct, Ridge(alpha=1.0)).fit(X(tr), np.log1p(tr["pickups"]))
            pred = np.clip(np.expm1(m.predict(X(va))), 0, None)
            rows.append({"model": "ridge", "setting": setting, "encoding": name,
                         **metrics(va["pickups"].to_numpy(), pred)})
    for name, num in (("integer", ["hour", "dow"]), ("sin/cos", ["hour_sin", "hour_cos", "dow_sin", "dow_cos"])):
        feats = ["zone_level", *lag_cols, *num]
        m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=seed)
        m.fit(tr[feats], np.log1p(tr["pickups"]))
        pred = np.clip(np.expm1(m.predict(va[feats])), 0, None)
        rows.append({"model": "gradient boosting", "setting": "with lags", "encoding": name,
                     **metrics(va["pickups"].to_numpy(), pred)})
    out = pd.DataFrame(rows)
    out.to_csv(TABLES2 / "encoding_experiment.csv", index=False)
    return out
