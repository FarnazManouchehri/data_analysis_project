"""Taxi-zone polygons from TLC's shapefile, read with the standard library only.

The shapefile is in NY State Plane Long Island (US feet), so distances are planar and exact enough
at city scale. Only polygon records (shape type 5) occur in this file.
"""
from __future__ import annotations

import struct
import zipfile

import numpy as np
import pandas as pd

from .settings import RAW

FT_PER_MILE = 5280.0


def _read_dbf(raw: bytes) -> pd.DataFrame:
    n_rec, hdr_len, rec_len = struct.unpack("<IHH", raw[4:12])
    fields, pos = [], 32
    while raw[pos] != 0x0D:
        name = raw[pos:pos + 11].split(b"\0")[0].decode()
        fields.append((name, raw[pos + 16]))
        pos += 32
    rows = []
    for i in range(n_rec):
        rec, off, row = raw[hdr_len + i * rec_len: hdr_len + (i + 1) * rec_len], 1, {}
        for name, length in fields:
            row[name] = rec[off:off + length].decode("utf-8", "replace").strip()
            off += length
        rows.append(row)
    return pd.DataFrame(rows)


def _read_polygons(raw: bytes) -> list[list[np.ndarray]]:
    shapes, pos = [], 100
    while pos < len(raw):
        content_len = struct.unpack(">I", raw[pos + 4:pos + 8])[0] * 2
        body = raw[pos + 8:pos + 8 + content_len]
        pos += 8 + content_len
        if struct.unpack("<i", body[:4])[0] != 5:
            shapes.append([])
            continue
        n_parts, n_pts = struct.unpack("<ii", body[36:44])
        parts = list(struct.unpack(f"<{n_parts}i", body[44:44 + 4 * n_parts])) + [n_pts]
        pts = np.frombuffer(body[44 + 4 * n_parts:44 + 4 * n_parts + 16 * n_pts], dtype="<f8").reshape(-1, 2)
        shapes.append([pts[parts[j]:parts[j + 1]] for j in range(n_parts)])
    return shapes


def _ring_area_centroid(r: np.ndarray) -> tuple[float, float, float]:
    x, y = r[:, 0], r[:, 1]
    cross = x[:-1] * y[1:] - x[1:] * y[:-1]
    a = cross.sum() / 2
    if a == 0:
        return 0.0, float(x.mean()), float(y.mean())
    return a, float(((x[:-1] + x[1:]) * cross).sum() / (6 * a)), float(((y[:-1] + y[1:]) * cross).sum() / (6 * a))


def load_shapes() -> tuple[pd.DataFrame, dict[int, list[np.ndarray]]]:
    """Return (zone_id, area_sqmi, cx, cy) per zone and the polygon rings per zone (in feet)."""
    with zipfile.ZipFile(RAW / "taxi_zones.zip") as z:
        dbf = _read_dbf(z.read("taxi_zones/taxi_zones.dbf"))
        shapes = _read_polygons(z.read("taxi_zones/taxi_zones.shp"))
    dbf["zone_id"] = dbf["LocationID"].astype(int)
    rows, rings = [], {}
    for zid, parts in zip(dbf["zone_id"], shapes):
        # Ring orientation varies; weight each ring's centroid by its absolute area (holes are rare here).
        acs = [_ring_area_centroid(r) for r in parts]
        area = sum(abs(a) for a, _, _ in acs)
        cx = sum(abs(a) * x for a, x, _ in acs) / area
        cy = sum(abs(a) * y for a, _, y in acs) / area
        rows.append({"zone_id": zid, "area_sqmi": area / FT_PER_MILE ** 2, "cx": cx, "cy": cy})
        rings.setdefault(zid, []).extend(parts)
    # A few LocationIDs appear twice (multi-record zones); merge them by area-weighted centroid.
    g = pd.DataFrame(rows)
    g["wx"], g["wy"] = g["cx"] * g["area_sqmi"], g["cy"] * g["area_sqmi"]
    g = g.groupby("zone_id", as_index=False)[["area_sqmi", "wx", "wy"]].sum()
    g["cx"], g["cy"] = g["wx"] / g["area_sqmi"], g["wy"] / g["area_sqmi"]
    return g[["zone_id", "area_sqmi", "cx", "cy"]], rings


def distance_miles(g: pd.DataFrame, to_zone: int) -> pd.Series:
    ref = g.set_index("zone_id").loc[to_zone]
    return np.hypot(g["cx"] - ref["cx"], g["cy"] - ref["cy"]) / FT_PER_MILE
