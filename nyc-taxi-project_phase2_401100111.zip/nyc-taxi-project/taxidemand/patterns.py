"""Unsupervised structure: zones clustered by the shape of their week, and days by the shape of their day.

Zone profiles are built from the train months only, so the cluster label can be used as a feature
without looking at May or June. The number of clusters is chosen by the rule in params.toml
([patterns]), written down before the result was seen.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import fcluster, linkage
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, silhouette_score

from .demand import HOLIDAYS, split_of
from .settings import TABLES2, params


def week_tensor(panel: pd.DataFrame, act: pd.Index) -> np.ndarray:
    """Array [zone, week, 168] of train pickups; partial weeks and the DST hour are NaN."""
    tr = panel[(split_of(panel["ts"]) == "train") & panel["zone_id"].isin(act)].copy()
    start = tr["ts"].min()
    tr["week"] = (tr["ts"] - start).dt.days // 7
    tr["slot"] = tr["ts"].dt.dayofweek * 24 + tr["ts"].dt.hour
    zi = pd.Index(act).get_indexer(tr["zone_id"])
    W = np.full((len(act), tr["week"].max() + 1, 168), np.nan)
    W[zi, tr["week"].to_numpy(), tr["slot"].to_numpy()] = tr["pickups"].to_numpy()
    return W


def represent(mean_week: np.ndarray, how: str = "share") -> np.ndarray:
    """Turn mean weekly counts into the shape of the week (volume removed)."""
    if how == "share":
        return mean_week / mean_week.sum(axis=1, keepdims=True) * 168  # mean slot = 1
    if how == "row_z":
        return (mean_week - mean_week.mean(1, keepdims=True)) / mean_week.std(1, keepdims=True)
    if how == "share_col_z":
        s = represent(mean_week, "share")
        return (s - s.mean(0)) / s.std(0)
    raise ValueError(how)


def embed(X: np.ndarray, var_kept: float) -> tuple[PCA, np.ndarray]:
    pca = PCA(n_components=var_kept, svd_solver="full").fit(X)
    return pca, pca.transform(X)


def kmeans(Z: np.ndarray, k: int, seed: int, n_init: int = 20) -> np.ndarray:
    return KMeans(n_clusters=k, n_init=n_init, random_state=seed).fit_predict(Z)


def choose_k(W: np.ndarray, seed: int) -> tuple[pd.DataFrame, dict]:
    cfg = params()["patterns"]
    rng = np.random.default_rng(seed)
    mean_week = np.nanmean(W, axis=1)
    pca, Z = embed(represent(mean_week), cfg["pca_var_kept"])
    ward = linkage(Z, method="ward")
    boot_Z = []
    for _ in range(cfg["bootstrap_reps"]):
        weeks = rng.integers(0, W.shape[1], W.shape[1])
        boot_Z.append(embed(represent(np.nanmean(W[:, weeks], axis=1)), cfg["pca_var_kept"])[1])
    alt = {how: embed(represent(mean_week, how), cfg["pca_var_kept"])[1] for how in ("row_z", "share_col_z")}
    rows, labels = [], {}
    for k in range(cfg["k_min"], cfg["k_max"] + 1):
        ref = kmeans(Z, k, seed)
        labels[k] = ref
        hier = fcluster(ward, k, criterion="maxclust")
        seed_ari = [adjusted_rand_score(ref, kmeans(Z, k, seed + 1 + s, n_init=1)) for s in range(cfg["seeds"])]
        boot_ari = [adjusted_rand_score(ref, kmeans(bz, k, seed)) for bz in boot_Z]
        rows.append({"k": k, "silhouette_kmeans": silhouette_score(Z, ref),
                     "silhouette_ward": silhouette_score(Z, hier),
                     "ari_kmeans_vs_ward": adjusted_rand_score(ref, hier),
                     "seed_ari_median": float(np.median(seed_ari)), "seed_ari_min": float(np.min(seed_ari)),
                     "boot_ari_median": float(np.median(boot_ari)), "boot_ari_p10": float(np.percentile(boot_ari, 10)),
                     **{f"scale_ari_{how}": adjusted_rand_score(ref, kmeans(Za, k, seed)) for how, Za in alt.items()},
                     "smallest_cluster": int(np.bincount(ref).min())})
    tab = pd.DataFrame(rows)
    ok = tab[(tab["boot_ari_median"] >= cfg["min_stability_ari"]) & (tab["seed_ari_median"] >= cfg["min_stability_ari"])]
    pick = ok.sort_values(["silhouette_kmeans", "k"], ascending=[False, True]).iloc[0] if len(ok) else \
        tab.sort_values("boot_ari_median", ascending=False).iloc[0]
    k = int(pick["k"])
    tab["chosen"] = tab["k"] == k
    tab.to_csv(TABLES2 / "k_selection.csv", index=False)
    scaling = {how: float(pick[f"scale_ari_{how}"]) for how in alt}
    return tab, {"k": k, "labels": labels[k], "pca": pca, "Z": Z, "X": represent(mean_week),
                 "mean_week": mean_week, "scaling_ari": scaling,
                 "pcs_kept": int(pca.n_components_), "var_explained": pca.explained_variance_ratio_.tolist()}


def order_clusters(labels: np.ndarray, mean_week: np.ndarray) -> np.ndarray:
    """Renumber clusters 1..k by total pickups (1 = busiest), so labels are stable and readable."""
    vol = pd.Series(mean_week.sum(1)).groupby(labels).sum().sort_values(ascending=False)
    remap = {old: new for new, old in enumerate(vol.index, start=1)}
    return np.vectorize(remap.get)(labels)


def describe_clusters(labels: pd.Series, static: pd.DataFrame, zones: pd.DataFrame,
                      mean_week: np.ndarray, act: pd.Index) -> pd.DataFrame:
    s = static.join(labels.rename("cluster_id"))
    vol = pd.Series(mean_week.sum(1), index=act)
    names = zones.set_index("zone_id")["zone"]
    X = mean_week / mean_week.sum(1, keepdims=True)
    rows = []
    for c, grp in s.groupby("cluster_id"):
        ids = grp.index
        idx = act.get_indexer(ids)
        prof = X[idx].mean(0).reshape(7, 24)
        top = vol.loc[ids].sort_values(ascending=False).head(4).index
        rows.append({
            "cluster_id": c, "zones": len(ids), "pickup_share_pct": 100 * vol.loc[ids].sum() / vol.sum(),
            "boroughs": ", ".join(f"{b} {n}" for b, n in grp["borough"].value_counts().items()),
            "peak_slot": f"{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][prof.argmax() // 24]} {prof.argmax() % 24:02d}:00",
            "weekend_share_pct": 100 * prof[5:].sum(), "night_share_pct": 100 * grp["night_share"].mean(),
            "weekend_ratio": grp["weekend_ratio"].mean(), "airport_bound_pct": 100 * grp["airport_bound_share"].mean(),
            "median_trip_mi": grp["median_trip_mi"].mean(), "dist_midtown_mi": grp["dist_midtown_mi"].mean(),
            "example_zones": "; ".join(names.loc[top]),
        })
    out = pd.DataFrame(rows)
    out.to_csv(TABLES2 / "cluster_profiles.csv", index=False)
    return out


def day_clusters(panel: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Cluster train+valid days by the shape of their city-wide 24-hour curve (June stays locked)."""
    cfg = params()["patterns"]
    p = panel[split_of(panel["ts"]) != "test"]
    hourly = p.groupby("ts")["pickups"].sum(min_count=1)
    D = hourly.groupby([hourly.index.normalize(), hourly.index.hour]).sum().unstack()
    D = D.div(D.sum(1), axis=0)  # the DST day sums to 1 over 23 hours
    sil = {k: silhouette_score(D.values, kmeans(D.values, k, seed)) for k in range(2, cfg["day_k_max"] + 1)}
    k = max(sil, key=sil.get)
    lab = kmeans(D.values, k, seed)
    days = pd.DataFrame({"date": D.index, "cluster": lab, "dow": D.index.dayofweek})
    days["kind"] = np.where(days["date"].dt.strftime("%Y-%m-%d").isin(HOLIDAYS), "holiday",
                            np.where(days["dow"] >= 5, "weekend", "weekday"))
    # Number day clusters so that 1 is the one holding most weekdays.
    order = days[days["kind"] == "weekday"]["cluster"].value_counts().reindex(range(k), fill_value=0)
    remap = {old: new for new, old in enumerate(order.sort_values(ascending=False).index, start=1)}
    days["cluster"] = days["cluster"].map(remap)
    days.to_csv(TABLES2 / "day_clusters.csv", index=False)
    sil_tab = pd.DataFrame({"k": list(sil), "silhouette": list(sil.values())})
    return days, sil_tab.assign(chosen=lambda t: t["k"] == k), D
