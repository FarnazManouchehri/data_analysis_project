"""Anomaly candidates at two levels, and a first sorting into data errors versus real events.

Trip level: records that are impossible (removed by the cleaning steps) or possible but unusual
(kept, counted here). Zone-hour level: hours whose pickups sit far from the zone's train profile.
Only January-May is searched; June stays locked.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .demand import HOLIDAYS, split_of
from .settings import TABLES2, params


def trip_candidates(clean: pd.DataFrame, log: pd.DataFrame) -> pd.DataFrame:
    std = clean["ratecode"] == "standard"
    moving = ~clean["zero_distance"]
    fpm = clean["fare_amount"] / clean["trip_distance"].where(moving)
    airport = clean["pu"].isin(params()["prep"]["airport_zones"]) | clean["do"].isin(params()["prep"]["airport_zones"])
    fast = (clean["speed_mph"] > 50) & moving
    kept = [
        ("zero distance, fare > $50", clean["zero_distance"] & (clean["fare_amount"] > 50),
         "mostly negotiated or flat fares typed in without a meter run: real trip, broken distance field"),
        ("under 1 minute with distance > 0", clean["short_trip"],
         "meter started and stopped at once or a GPS jump: data error for duration, trip itself uncertain"),
        ("standard rate, fare per mile > $50 (distance >= 0.5 mi)", std & (fpm > 50) & (clean["trip_distance"] >= 0.5),
         "long waits in traffic can do this for short trips, but values far above that are entry errors"),
        ("implied speed 50-80 mph", fast,
         f"{100 * (fast & airport).sum() / max(fast.sum(), 1):.0f}% touch an airport (highway rides): mostly real"),
        ("meter running 3-5 hours", clean["duration_min"].between(180, 300),
         "very few real trips last this long; most are meters left on"),
    ]
    rows = [{"level": "trip", "candidate": name, "status": "kept, flagged", "rows": int(mask.sum()),
             "share_pct": 100 * mask.mean(), "reading": reading} for name, mask, reading in kept]
    for _, r in log[log["removed"] > 0].iterrows():
        rows.append({"level": "trip", "candidate": r["rule"], "status": f"removed ({r['step']})", "rows": int(r["removed"]),
                     "share_pct": 100 * r["removed"] / log["rows_in"].iloc[0],
                     "reading": "physically impossible or a bookkeeping row: data error"})
    out = pd.DataFrame(rows)
    out.to_csv(TABLES2 / "trip_anomaly_candidates.csv", index=False)
    return out


def zone_hour_candidates(table: pd.DataFrame, zones: pd.DataFrame) -> dict:
    """Robust z of log(1 + pickups) against the train zone x weekday x hour mean, per zone."""
    cfg = params()["anomaly"]
    d = table[table["split"] != "test"][["zone_id", "ts", "pickups", "hour", "dow", "split"]].copy()
    prof = d[d["split"] == "train"].groupby(["zone_id", "dow", "hour"])["pickups"].mean().rename("expected")
    d = d.join(prof, on=["zone_id", "dow", "hour"])
    d["resid"] = np.log1p(d["pickups"]) - np.log1p(d["expected"])
    tr = d[d["split"] == "train"].groupby("zone_id")["resid"]
    med = tr.median()
    mad = 1.4826 * tr.apply(lambda r: np.median(np.abs(r - np.median(r))))
    d["z"] = (d["resid"] - d["zone_id"].map(med)) / d["zone_id"].map(mad).clip(lower=0.05)
    d["gap"] = d["pickups"] - d["expected"]
    flag = d[(d["z"].abs() > cfg["zone_hour_z"]) & (d["gap"].abs() >= cfg["zone_hour_min_abs"])].copy()
    flag["direction"] = np.where(flag["gap"] > 0, "above", "below")
    names = zones.set_index("zone_id")["zone"]
    flag["zone"] = flag["zone_id"].map(names)
    per_hour = flag.groupby("ts").agg(zones=("zone_id", "size"), below=("direction", lambda x: (x == "below").sum()))
    per_hour["kind"] = np.where(per_hour["zones"] >= cfg["citywide_min_zones"], "city-wide",
                                np.where(per_hour["zones"] <= 2, "isolated", "several zones"))
    flag = flag.join(per_hour["kind"], on="ts")
    flag["holiday"] = flag["ts"].dt.strftime("%Y-%m-%d").map(HOLIDAYS).fillna("")
    flag.to_csv(TABLES2 / "zone_hour_anomalies.csv", index=False)

    city = (per_hour[per_hour["kind"] == "city-wide"].reset_index()
            .assign(date=lambda t: t["ts"].dt.normalize())
            .groupby("date").agg(hours=("ts", "size"), max_zones=("zones", "max"), below_zones=("below", "sum"),
                                 first=("ts", "min"), last=("ts", "max")))
    city["holiday"] = city.index.strftime("%Y-%m-%d").map(HOLIDAYS).fillna("")
    city.to_csv(TABLES2 / "citywide_anomaly_days.csv")
    iso = flag[flag["kind"] == "isolated"].assign(abs_gap=lambda t: t["gap"].abs()).sort_values("abs_gap", ascending=False)
    top_iso = iso.drop_duplicates("zone_id").head(12)  # biggest spike per zone
    top_iso[["ts", "zone_id", "zone", "pickups", "expected", "z", "direction"]].to_csv(
        TABLES2 / "isolated_spikes_top.csv", index=False)

    # Data-error screen: whole-city hours far below what the zones' profiles add up to.
    hourly = d.groupby("ts")[["pickups", "expected"]].sum()
    hourly["ratio"] = hourly["pickups"] / hourly["expected"]
    feed_gaps = hourly[hourly["ratio"] < 0.5]
    daily_counts = flag.groupby([flag["ts"].dt.normalize(), "direction"]).size().unstack(fill_value=0)
    return {"flags": flag, "per_hour": per_hour, "city_days": city, "top_isolated": top_iso,
            "feed_gaps": feed_gaps, "daily_counts": daily_counts, "searched": len(d),
            "hourly_ratio": hourly["ratio"]}
