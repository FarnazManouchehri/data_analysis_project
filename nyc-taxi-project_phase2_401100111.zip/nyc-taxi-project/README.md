# NYC yellow-taxi zone demand — Data Analysis course project (Track A)

Day-ahead forecasting of hourly pickups per taxi zone, from the NYC TLC Trip Record Data (yellow taxi, January–June 2024).

**Status:**
- Phase 1 done: problem framing, provenance, structure and quality audit, time/space EDA, leakage analysis, split and baselines.
- Phase 2 done: cleaning pipeline, missing-data decisions, feature table with catalogue, cyclic-encoding test, spatial features, PCA, zone and day clustering with stability checks, anomaly candidates.

## Phase 1 deliverables
| Path | What it is |
|---|---|
| `reports/phase1.pdf` | Phase 1 report (Persian), built from `writeup/phase1_fa.md` |
| `PROJECT_CARD.md` | The 14 required project-card items |
| `taxidemand/` | Python package: download, loading, audit, figures, zone-hour panel, baselines |
| `artifacts/phase1/` | Everything the package writes: `headline.json`, `tables/*.csv`, `figures/*.png` (13) |
| `tlc/SOURCES.md` | Data source, files, checksums, schema, known issues |
| `AI_USAGE.md` | AI usage log |

## Phase 2 deliverables
| Path | What it is |
|---|---|
| `reports/phase2.pdf` | Phase 2 report (Persian), built from `writeup/phase2_fa.md` |
| `taxidemand/refine.py`, `features.py`, `geo.py`, `patterns.py`, `oddities.py`, `phase2.py` | Data-preparation pipeline, features, clustering, anomaly candidates |
| `artifacts/phase2/figures/` | 11 figures, including PCA (`p2_04`, `p2_08`) and clustering (`p2_05`–`p2_07`, `p2_09`) |
| `artifacts/phase2/tables/feature_catalog.csv` | Every feature, its group, definition, what it adds, and when it is available |
| `artifacts/phase2/tables/*.csv`, `headline.json` | Every number in the Phase 2 report |

## Reproduce
Python 3.11+ (tested with 3.13.1), about 800 MB of disk and 8 GB of RAM.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .
make all
```

`make all` runs these steps, which can also be run one at a time:

```bash
python -m taxidemand.fetch      # download 6 Parquet files, zone lookup and zone shapes into tlc/downloads, verify SHA-256
python -m taxidemand.run_all    # Phase 1: audit, tables, figures, panel, baselines -> artifacts/phase1 (~1.5 min)
python -m taxidemand.phase2     # Phase 2: cleaning pipeline, features, PCA, clustering, anomalies -> artifacts/phase2 (~75 s)
python tools/render_pdf.py writeup/phase1_fa.md reports/phase1.pdf   # needs Google Chrome
python tools/render_pdf.py writeup/phase2_fa.md reports/phase2.pdf
```

All parameters (months, split dates, plausibility limits, cluster-selection rule, anomaly thresholds, seed = 7) are in `params.toml`. The June test month is never scored in Phases 1 and 2.

## Layout
```
params.toml              every fixed choice: months, URLs + SHA-256, split dates, rule limits, seed
pyproject.toml           package metadata and pinned dependencies
Makefile                 data -> Phase 1 -> Phase 2 -> reports
taxidemand/
  settings.py            paths, params loader, plot theme
  fetch.py               download + checksum
  ingest.py              raw Parquet -> compact DataFrame (no filtering)
  checks.py              17 quality rules, schema, missingness tests, univariate stats
  demand.py              zone x hour panel, temporal split, baselines, leakage designs, daily anomalies
  explore.py             Phase 1 figures
  run_all.py             runs Phase 1, writes artifacts/phase1/headline.json
  refine.py              Phase 2 cleaning steps with a row log, missing-data table, panel with DST hour as NaN
  geo.py                 zone polygons, areas and centroids from the TLC shapefile (standard library only)
  features.py            calendar, cyclic, lag, zone and spatial features; catalogue; encoding test
  patterns.py            weekly profiles, PCA, k-means / Ward, k selection and stability, day clustering
  oddities.py            trip-level and zone-hour anomaly candidates
  figures_p2.py          Phase 2 figures
  phase2.py              runs Phase 2, writes artifacts/phase2/headline.json
tlc/
  SOURCES.md             provenance and schema
  downloads/             raw TLC files (git-ignored)
  derived/               panels, clean trips, feature table (git-ignored)
artifacts/phase1/        headline.json, tables/, figures/
artifacts/phase2/        headline.json, tables/, figures/
writeup/phase{1,2}_fa.md report sources (Markdown, RTL)
tools/render_pdf.py      Markdown -> HTML -> PDF with headless Chrome
reports/phase{1,2}.pdf   the submitted reports
```
