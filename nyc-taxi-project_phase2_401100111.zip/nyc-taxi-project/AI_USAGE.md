# AI usage log

The course allows AI tools if their use is transparent and the student can explain and defend every result.

## Phase 1
| Item | Details |
|---|---|
| Tool | Claude (Anthropic) via Claude Code, model Claude Opus 5.5 |
| What it did | Chose the subset (yellow taxi, H1 2024), wrote the `taxidemand/` code, ran it, inspected the figures, and drafted the Persian report, `PROJECT_CARD.md`, `README.md` and `tlc/SOURCES.md` from the pipeline outputs. |
| Where numbers come from | Every number in the report is copied from `artifacts/phase1/headline.json` or `artifacts/phase1/tables/*.csv`, which `python -m taxidemand.run_all` writes. |
| Corrections made during the work | (1) A naive "total ≠ sum of parts" rule flagged 29.1% of rows. The assistant traced this to vendor-specific fee encoding and made the rule vendor-aware (0.19% remain). (2) The first anomaly rule used only a robust z-score and flagged days only 5–7% off, so a minimum 10% deviation was added. |
| Used inside the analysis? | No. No LLM is used as a model, feature extractor or labeller. |
| Unverified statements | Explanations for anomalous days (snow on 13 Feb, Valentine's Day, unexplained early-April rise) are hypotheses; they have not been checked against external data such as weather. |

## Phase 2
| Item | Details |
|---|---|
| Tool | Claude (Anthropic) via Claude Code, model Claude Opus 5.5 |
| What it did | Wrote `refine.py`, `geo.py`, `features.py`, `patterns.py`, `oddities.py`, `figures_p2.py` and `phase2.py`, ran them, inspected every figure, and drafted the Persian Phase 2 report from the outputs. |
| Where numbers come from | Every number in the Phase 2 report is copied from `artifacts/phase2/headline.json` or `artifacts/phase2/tables/*.csv`, which `python -m taxidemand.phase2` writes. |
| Corrections made during the work | (1) The first cluster-selection rule checked only bootstrap stability and picked k = 2; single-start runs with other seeds reproduced it with median ARI 0.15, so the rule now also requires seed stability (k = 3). This is stated in the report and in `params.toml`. (2) Within-zone correlations of zone-level features were tiny non-zero numbers caused by floating-point noise; they are now reported as not applicable. |
| Used inside the analysis? | No. No LLM is used as a model, feature extractor or labeller. |
| Unverified statements | Causes given for individual anomalies (snow on 13 Feb, the Midtown dip on 28 Mar, late JFK arrivals on 28 May) are hypotheses; no weather, traffic or event data is connected. Super Bowl night and federal holidays are calendar facts. |

> **Student action required:** re-run the pipeline, check each design choice (subset, active-zone threshold, split dates, rules), and describe your own review here before submission.
